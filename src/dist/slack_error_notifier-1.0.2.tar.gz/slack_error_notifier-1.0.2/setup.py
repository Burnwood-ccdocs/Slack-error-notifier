#!/usr/bin/env python3
"""Setup script for slack_error_notifier."""

from pathlib import Path
from setuptools import setup

ROOT = Path(__file__).parent.parent  # project root
readme_path = ROOT / "README.md"
long_description = readme_path.read_text(encoding="utf-8") if readme_path.exists() else "Slack error notification helper."

setup(
    name="slack_error_notifier",
    version="1.0.2",
    description="Simple library for sending error notifications to Slack",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Your Name",
    author_email="your.email@example.com",
    py_modules=["slack_error_notifier"],
    install_requires=["slack_sdk>=3.19.0"],
    python_requires=">=3.7",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3 :: Only",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    project_urls={
        "Documentation": "https://internal-wiki.example.com/slack-error-notifier",
        "Source": "https://git.example.com/infra/slack-error-notifier",
    },
    include_package_data=True,
) 